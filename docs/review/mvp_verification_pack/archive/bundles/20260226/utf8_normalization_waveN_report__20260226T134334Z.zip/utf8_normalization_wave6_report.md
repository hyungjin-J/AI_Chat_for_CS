# UTF-8 Normalization Report

- generated_at_utc: 2026-02-24T14:09:09.751425+00:00
- dry_run: NO
- candidate_count: 6
- changed_count: 6
- skipped_count: 0
- verification_method: decoded-text SHA-256 + byte SHA-256

| file | old_encoding | action | old_bytes_sha256 | new_bytes_sha256 | old_decoded_sha256 | new_decoded_sha256 | line_endings(old->new) | status |
|---|---|---|---|---|---|---|---|---|
| `docs/review/mvp_verification_pack/artifacts/phase2_1_pr2_notion_sync_status_202603XX.txt` | `utf-8-sig` | `BOM_REMOVED` | `bdbb362730e3032afa14c3b75ca14598cb5a53024388d6710d5fcf7149ea2a8b` | `8eb5b3bd1008873c3da2379b9be14d49737ab5023da112a023c9c84dfde7cb17` | `8eb5b3bd1008873c3da2379b9be14d49737ab5023da112a023c9c84dfde7cb17` | `8eb5b3bd1008873c3da2379b9be14d49737ab5023da112a023c9c84dfde7cb17` | `MIXED(CRLF=4,LF=3,CR=0)->MIXED(CRLF=4,LF=3,CR=0)` | `CHANGED` |
| `docs/review/mvp_verification_pack/artifacts/phase2_1_pr3_scheduler_observability_202603XX.txt` | `utf-8-sig` | `BOM_REMOVED` | `131722e9028dc92f3f9ca157d69c0d094dcbfa89b6965b1ddec974a1374905e8` | `b5502fe9ba3205c02b4b482ca85ddabe1906c892fd58c4b12e787de3a7a9d439` | `b5502fe9ba3205c02b4b482ca85ddabe1906c892fd58c4b12e787de3a7a9d439` | `b5502fe9ba3205c02b4b482ca85ddabe1906c892fd58c4b12e787de3a7a9d439` | `MIXED(CRLF=1,LF=9,CR=0)->MIXED(CRLF=1,LF=9,CR=0)` | `CHANGED` |
| `docs/review/mvp_verification_pack/artifacts/phase2_dirty_delta_202603XX.txt` | `utf-8-sig` | `BOM_REMOVED` | `ca3d5a0581d8814d7f5863df6011c442ccdfa0396814f5fe296d87eb2a0f8e95` | `54704b46d0f97ccb0523aabe4520ee492cb92be620dc75b0c5e67e9f3b26efd8` | `54704b46d0f97ccb0523aabe4520ee492cb92be620dc75b0c5e67e9f3b26efd8` | `54704b46d0f97ccb0523aabe4520ee492cb92be620dc75b0c5e67e9f3b26efd8` | `CRLF->CRLF` | `CHANGED` |
| `docs/review/mvp_verification_pack/artifacts/phase2_spec_consistency_output_202603XX.txt` | `utf-8-sig` | `BOM_REMOVED` | `bfa7f0d14772cb246d6698bcd1513f278c402262e71de378dad53b55a11a4edb` | `9599ef56f46ec60393d54c973b9dfeac51617ad4be63b4f894da23b9542ef146` | `9599ef56f46ec60393d54c973b9dfeac51617ad4be63b4f894da23b9542ef146` | `9599ef56f46ec60393d54c973b9dfeac51617ad4be63b4f894da23b9542ef146` | `MIXED(CRLF=1,LF=15,CR=0)->MIXED(CRLF=1,LF=15,CR=0)` | `CHANGED` |
| `docs/review/mvp_verification_pack/artifacts/pii_masking_checks.txt` | `utf-8-sig` | `BOM_REMOVED` | `f1559139175c7a490479ac8353a470d0edcdd813dc974d7d7f26b50ba83fb7bf` | `dbbddcd454b6a428a90ea57f459e7203b665d438d814e7fabc0470cd508cffeb` | `dbbddcd454b6a428a90ea57f459e7203b665d438d814e7fabc0470cd508cffeb` | `dbbddcd454b6a428a90ea57f459e7203b665d438d814e7fabc0470cd508cffeb` | `MIXED(CRLF=1,LF=5,CR=0)->MIXED(CRLF=1,LF=5,CR=0)` | `CHANGED` |
| `docs/review/mvp_verification_pack/artifacts/provider_evidence_consistency_output.txt` | `utf-8-sig` | `BOM_REMOVED` | `2766dff348b92d3ab28f986af9497e9cf8740527035d7cd312cb011cde9a9fb5` | `a90b19c33b68a25766842d2e71328e5019f511cf4d0a37b716b8ca898c6eb6d2` | `a90b19c33b68a25766842d2e71328e5019f511cf4d0a37b716b8ca898c6eb6d2` | `a90b19c33b68a25766842d2e71328e5019f511cf4d0a37b716b8ca898c6eb6d2` | `CRLF->CRLF` | `CHANGED` |
